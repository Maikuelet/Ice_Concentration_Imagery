%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%% COPERNICUS DATA ANALYSIS CODE %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% - AUTHOR: MIQUEL ALTADILL LLASAT
% - COPYRIGHT: Copyright (c) 2020, The MathWorks, Inc.
% - DATE:   06/04/2021
% - OBJECTIVE: Ice concentration analysis
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% - DESCRIPTION:
%       
clc
clear all
close all


%% MODES
% Mode = 1 -> Visualize ice conc in a certain year
% Mode = 2 -> Download ice conc gif
% Mode = 3 -> Ice Countour plot
% Mode = 4 -> Ice Countrour 3d Globe
% Pole = 1 -> North Pole
% Pole = 2 -> South Pole
mode =2;
polo =2;


datafold = "Data_South_Au1";

filename = 'sea_ice_animationSP_Au1.gif'; % For gif file


%% Create Variable Containing Data Files with Ice Concentration
if ~exist(datafold,"dir")
    error("You need to create a data folder and copy the downloaded file to the data folder and extract contents.")
end


datafolder = fullfile(pwd,datafold);
t = struct2table(dir(fullfile(datafolder,"*")));
files = string(t.name(contains(t.name,"conc") & contains(t.name,".nc")));

%% Examine Ice Concentration Data
file = fullfile(datafolder,files(1));
ncdisp(file);
yearinsp = ncreadatt(file,'/',"time_coverage_start");
yearinsp1 = extractBefore(yearinsp,"-");    % First Year
yearinsp2 = extractAfter(yearinsp,"-");    
yearinsp2 = extractBefore(yearinsp2,"-");    % Month
yearinsp2 = convertCharsToStrings(yearinsp2);
yearinsp2 = str2double(yearinsp2);
[month] = whatmonth(yearinsp2);

cachefile = fullfile(datafolder,"ice_conc_cache.mat");
if exist(cachefile,"file")
     cache = load(cachefile);
     years = string(extractAfter(fieldnames(cache),"Year_"));
     disp("Creocache");
 else
     years = extractAfter(files,"v2p0_");
     %years = extractBefore(years,"12011200.nc"); %For 1Dec
     years = extractBefore(years,"08011200.nc"); %For 1Aug
end


% years = extractAfter(files,"v2p0_");
% years = extractBefore(years,"12011200.nc");

%% Read Ice Concentration Data and Copyright Attribute
ice_concentration = ncread(file,"ice_conc");
lat = ncread(file,"lat");
lon = ncread(file,"lon");


 copyright = "Copyright � (2011) EUMETSAT";


%% Visualize Sea Ice Concentration in 2D Map
data = load(fullfile(pwd,"Data","ice_colormap"));
ice_colormap = data.ice_colormap;
land = shaperead("landareas","UseGeoCoords",true);

startYear = years(1);
attribution = copyright;
titlestr = ["Ice Concentration"; month  + startYear; attribution];

gcolor = [1 1 1];
landcolor = [204 204 204]/255;
levels = 0:5:100;
latlim = double([min(lat(:)) max(lat(:))]);


 if mode == 1

figure("Colormap",ice_colormap)
title(titlestr)
set(gcf, 'color', 'white');     % For white background

if polo == 1
    o= 90;
end
if  polo == 2
    o=-90;
end
ax = axesm("eqaazim", ...
    "Origin",[o 0 0],"MapLatLimit",latlim, ...
    "Grid","on","GColor",gcolor);
caxis(ax,[min(levels) max(levels)])

% Set the axes limits to zoom into the map.
axis(ax,"off")
nlim = .82;
set(ax,"XLim",[-nlim,nlim],"YLim",[-nlim,nlim])

% Display polygons of land areas and a texture map of ice concentrations.
geoshow(lat,lon,ice_concentration,"DisplayType","texturemap");
geoshow(land,"FaceColor",landcolor)

% Add a color bar and label.
h = colorbar("Ticks",levels);
h.Label.String = "Sea Ice Concentration [%]";
end

%% Animate Sea Ice Concentration Over Time in Live Editor

% makemap(latlim,ice_colormap);
% iceTextureMap = geoshow(lat,lon,ice_concentration,"DisplayType","texturemap");
% geoshow(land,"FaceColor",landcolor)
% for k = length(years):-1:1
%     year = years(k);
%     [ice_concentration, newTitle] = readData(file,cachefile,startYear,year);
%     set(iceTextureMap,"CData",ice_concentration)
%     title(newTitle)
%     drawnow
% end

%% Animate Sea Ice Concentration Using Animated GIF
if mode ==2
    
% data = load(fullfile(pwd,datafold,"ice_colormap"));
% ice_colormap = data.ice_colormap;
% land = shaperead("landareas","UseGeoCoords",true);
% latlim = double([min(lat(:)) max(lat(:))]);
% landcolor = [204 204 204]/255;
% startYear = years(1);

hfig = makemap(latlim,ice_colormap,polo,"Visible","off");



iceTextureMap = geoshow(lat,lon,ice_concentration,"DisplayType","texturemap");
geoshow(land,"FaceColor",landcolor)
set(gcf, 'color', 'white');     % For white background
if exist(filename,'file')
    delete(filename)
end
for k = 1:length(years)
    year = years(k);
    [ice_concentration, newTitle] = readData(file,cachefile,startYear,year,month);
    set(iceTextureMap,"CData",ice_concentration)
    title(newTitle)
    writeAnimatedGIF(hfig,filename)
end

end

%% Visualize Contours of Sea Ice Concentration in 2D Map
if mode ==3

makemap(latlim,ice_colormap);

year = "1981";
[ice_concentration, newTitle, attribution] = readData(file,cachefile,startYear,year,month);
title(newTitle)   

%Use geoloc2grid to create a regular gridded data set from longitude and latitude information.
%warning off map:geoloc2grid:possibleLongitudeWrap
cellSize = .5;
[Z,refvec] = geoloc2grid(double(lat),double(lon),ice_concentration,cellSize);

% Display ice concentration, land data, and create contour lines
geoshow(lat,lon,ice_concentration,"DisplayType","texturemap")
geoshow(land,"FaceColor",landcolor)
iceContourMap = contourm(Z,refvec,"LevelList",levels,"Color","k");


end


if mode ==4
  
makemap(latlim,ice_colormap);

year = "1981";
[ice_concentration, newTitle, attribution] = readData(file,cachefile,startYear,year,month);
title(newTitle)   

%Use geoloc2grid to create a regular gridded data set from longitude and latitude information.
%warning off map:geoloc2grid:possibleLongitudeWrap
cellSize = .5;
[Z,refvec] = geoloc2grid(double(lat),double(lon),ice_concentration,cellSize);

% Display ice concentration, land data, and create contour lines
geoshow(lat,lon,ice_concentration,"DisplayType","texturemap")
geoshow(land,"FaceColor",landcolor)
iceContourMap = contourm(Z,refvec,"LevelList",levels,"Color","k");

    
    s = contourToGeoshape(iceContourMap);
uif = uifigure("Colormap",ice_colormap,"Visible","off");
uif.Name = "Ice Concentration : December " + year + " " + attribution;
ug = uigridlayout(uif,[1,2],"ColumnWidth",{'1x','.1x'});
up1 = uipanel(ug,"BackgroundColor",uif.Color,"BorderType","none");
up2 = uipanel(ug,"BackgroundColor",uif.Color,"BorderType","none");
gg = geoglobe(up1,"Terrain","none","Basemap","streets-dark","NextPlot","add","Visible","off");
ax = axes(up2,"Units","normalized","Position",[.05 0.02 .005 .95]);
axis(ax,"off")
caxis(ax,[0 100])
h = colorbar(ax);
h.Label.String = "Sea Ice Concentration [%]";
h.Ticks = levels;
n = 0;
for level = levels
    index = s.Level == level;
    n = min(n + 1, length(ice_colormap));
    color = ice_colormap(n,:);
    geoplot3(gg,s(index).Latitude,s(index).Longitude,[],"Color",color)
end
uif.Visible = "on";
gg.Visible = "on";
    
end













%% LOCAL FUNCTIONS


% Create new map axes for display of ice concentration

function hfig = makemap(latlim,ice_colormap,polo,varargin)
    gcolor = [1 1 1];
    levels = 0:5:100;
    
    hfig = figure("Colormap",ice_colormap,varargin{:});
    
    if polo == 1
        o= 90;
    end
    if  polo == 2
        o=-90;
    end

    
    ax = axesm("eqaazim",...
        "Origin",[o 0 0],"MapLatLimit",latlim, ...
        "Grid","on","GColor",gcolor);
    
    caxis(ax,[min(levels),max(levels)])
    axis(ax,"off")
    nlim = .82;
    set(ax,"XLim",[-nlim,nlim],"YLim",[-nlim,nlim])
    
    h = colorbar;
    h.Ticks = levels;
    h.Label.String = "Sea Ice Concentration [%]";
end


%Get frame and write as animated GIF
function writeAnimatedGIF(hfig, filename)
    data = getframe(hfig);
    RGB = data.cdata;
    [frame, cmap] = rgb2ind(RGB, 256, 'nodither');
    folder = fullfile(pwd,'Images');
    folder = fullfile(folder,filename);
    % Write frame to the GIF File.
    if ~exist(filename,'file')
        imwrite(frame,cmap,filename,'gif','Loopcount',inf,'DelayTime',.5);
    else
        imwrite(frame,cmap,filename,'gif','WriteMode','append','DelayTime',.5);
    end
end

% Read ice concentration and copyright attribute
function [ice_concentration, newTitle, attribution] = readData(file,cachefile,startYear,year,month)
yearfile = replace(file,startYear,year);
if exist(yearfile,"file")
    ice_concentration = ncread(yearfile,"ice_conc");
else
    yearstr = "Year_" + year;
    data = load(cachefile,yearstr);
    ice_concentration = data.(yearstr).IceConcentration;
end

copyright = "Copyright � (2011) EUMETSAT";
attribution = copyright;
newTitle = ["Ice Concentration";  month + year; attribution];
end


%Convert  contour matrix created with contourm to geoshape vector
function s = contourToGeoshape(c)
    lon = c(1,:);
    lat = c(2,:);
    n = length(lat);
    k = 1;
    index = 1;
    S = struct("Lat",[],"Lon",[],"Level",[]);
    while k < n
        level = lon(k);
        numVertices = lat(k);
        S(index).Lat = lat(k+1:k+numVertices);
        S(index).Lon = lon(k+1:k+numVertices);
        S(index).Level = level;
        k = k + numVertices + 1;
        index = index + 1;
    end
    
    % Remove single vertex.
    s = geoshape(S);
    index = false(length(s),1);
    for k = 1:length(s)
        if isscalar(s(k).Latitude)
            index(k) = true;
        end
    end
    s(index) = [];
end

function [x] = whatmonth(yearinsp2)

if yearinsp2 == 1
    x = 'January ';
end
if yearinsp2 == 8
    x = 'August ';
end
if yearinsp2 == 12
    x = 'December ';
end


end